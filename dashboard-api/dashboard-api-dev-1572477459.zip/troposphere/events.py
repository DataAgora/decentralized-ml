# Copyright (c) 2012-2019, Mark Peek <mark@peek.org>
# All rights reserved.
#
# See LICENSE file for full license.


from . import AWSObject
from . import AWSProperty
from .validators import integer


class Condition(AWSProperty):
    props = {
        'Key': (str, False),
        'Type': (str, False),
        'Value': (str, False),
    }


class EventBusPolicy(AWSObject):
    resource_type = "AWS::Events::EventBusPolicy"

    props = {
        'Action': (str, True),
        'Condition': (Condition, False),
        'Principal': (str, True),
        'StatementId': (str, True),
    }


class AwsVpcConfiguration(AWSProperty):
    props = {
        'AssignPublicIp': (str, False),
        'SecurityGroups': ([str], False),
        'Subnets': ([str], True),
    }


class NetworkConfiguration(AWSProperty):
    props = {
        'AwsVpcConfiguration': (AwsVpcConfiguration, False),
    }


class EcsParameters(AWSProperty):
    props = {
        'Group': (str, False),
        'LaunchType': (str, False),
        'NetworkConfiguration': (NetworkConfiguration, False),
        'PlatformVersion': (str, False),
        'TaskCount': (integer, False),
        'TaskDefinitionArn': (str, True),
    }


class InputTransformer(AWSProperty):
    props = {
        'InputPathsMap': (dict, False),
        'InputTemplate': (str, True),
    }


class KinesisParameters(AWSProperty):
    props = {
        'PartitionKeyPath': (str, True),
    }


class RunCommandTarget(AWSProperty):
    props = {
        'Key': (str, True),
        'Values': ([str], True),
    }


class RunCommandParameters(AWSProperty):
    props = {
        'RunCommandTargets': ([RunCommandTarget], True),
    }


class SqsParameters(AWSProperty):
    props = {
        'MessageGroupId': (str, True),
    }


class Target(AWSProperty):
    props = {
        'Arn': (str, True),
        'EcsParameters': (EcsParameters, False),
        'Id': (str, True),
        'Input': (str, False),
        'InputPath': (str, False),
        'InputTransformer': (InputTransformer, False),
        'KinesisParameters': (KinesisParameters, False),
        'RoleArn': (str, False),
        'RunCommandParameters': (RunCommandParameters, False),
        'SqsParameters': (SqsParameters, False),
    }


class Rule(AWSObject):
    resource_type = "AWS::Events::Rule"

    props = {
        'Description': (str, False),
        'EventPattern': (dict, False),
        'Name': (str, False),
        'RoleArn': (str, False),
        'ScheduleExpression': (str, False),
        'State': (str, False),
        'Targets': ([Target], False),
    }

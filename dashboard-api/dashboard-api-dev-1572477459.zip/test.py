import boto3
from boto3.dynamodb.conditions import Key, Attr

APPLICATION_NAME = "cloud-node"
PIPELINE_NAME = 'cloud-node-deploy'
DEPLOYMENT_NAME = 'deploy-elb-{}'
AWS_REGION = 'us-west-1'

def _get_dynamodb_table(table_name):
    """
    Helper function that returns an AWS DynamoDB table object.
    """
    dynamodb = boto3.resource('dynamodb', region_name='us-west-1')
    table = dynamodb.Table(table_name)
    return table

def _remove_api_key(user_id, repo_id):
    table = _get_dynamodb_table("ApiKeys")
    try:
        response = table.scan(
            FilterExpression=Attr('RepoId').eq(repo_id)
        )
        items = response['Items']
        assert len(items) > 0, "Should have found repo in API keys table!"
        item = items[0]
        api_key = item['Key']
        table.delete_item(
            Key={
                'Key': item['Key'],
                'OwnerId': item['OwnerId']
            }
        )
        return api_key
    except Exception as e:
        print(str(e))
        raise Exception("Error while deleting API key.")

def _remove_logs(repo_id):
    """
    Removes the logs for a repo.
    """
    logs_table = _get_dynamodb_table("UpdateStore")
    try:
        response = logs_table.query(
            KeyConditionExpression=Key('RepoId').eq(repo_id)
        )
        with logs_table.batch_writer() as batch:
            for item in response["Items"]:
                batch.delete_item(
                    Key={
                        'RepoId': item['RepoId'],
                        'Timestamp': item['Timestamp']
                    }
                )
        print("Successfully deleted logs!")
        return True
    except Exception as e:
        raise Exception("Error while getting logs for repo. " + str(e))

def _remove_repo_from_user_details(user_id, repo_id, api_key):
    """
    Upon removing a repo, remove the repo from the user's details.
    """
    table = _get_dynamodb_table("UsersDashboardData")
    try:
        response = table.get_item(
            Key={
                "UserId": user_id,
            }
        )
        data = response["Item"]
        repos_managed = data['ReposManaged']
        api_keys = data['ApiKeys']
        if repo_id in repos_managed and api_key in api_keys:
            repos_managed.remove(repo_id)
            api_keys.remove(api_key)
            table.update_item(
                Key={
                    "UserId": user_id,
                },
                UpdateExpression='SET ReposRemaining = :val1, ReposManaged = :val2, ApiKeys = :val3',
                ExpressionAttributeValues={
                    ':val1': data['ReposRemaining'] + 1,
                    ':val2': repos_managed,
                    ':val3': api_keys,
                }
            )
            print("Successfully removed repo_id from user details!")
            return True
        else:
            raise Exception("Could not find corresponding API key or repo id!")
    except:
        raise Exception("Error while getting user dashboard data.")

def _remove_repo_details(user_id, repo_id):
    """
    Removes a repo's details.
    """
    repos_table = _get_dynamodb_table("Repos")
    try:
        response = repos_table.delete_item(
            Key={
                "Id": repo_id,
                "OwnerId": user_id,
            }
        )
        print("Removed repo details!")
        return True
    except:
        raise Exception("Error while getting repo details.")

def _remove_creds_from_repo(user_id, repo_id):
    repos_table = _get_dynamodb_table("Repos")
    users_table = _get_dynamodb_table('jupyterhub-users')
    try:
        response = repos_table.get_item(
            Key={
                "Id": repo_id,
                "OwnerId": user_id,
            }
        )
        repo_details = response["Item"]
        username = repo_details['creds']
        repos_table.update_item(
            Key={
                "Id": repo_id,
                "OwnerId": user_id,
            },
            UpdateExpression='SET creds = :val1',
            ExpressionAttributeValues={
                ':val1': 'N/A',
            }
        )
        users_table.update_item(
            Key = {
                'username': username
            },
            UpdateExpression='SET in_use = :val1',
            ExpressionAttributeValues={
                ':val1': False
            }
        )
    except:
        raise Exception("Error while removing repo creds.")

repo_id = '1f0069407946a7c3d37bc264fabe9af2'
user_id = 50
api_key = '7a74914a98bbafe09a938079a7d42855ba42fe3b5911366b53274fc8b567f271'
_remove_repo_details(user_id, repo_id)
